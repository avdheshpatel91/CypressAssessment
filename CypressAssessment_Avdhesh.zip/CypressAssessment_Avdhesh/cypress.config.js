const { defineConfig } = require("cypress");
const fs = require('fs')

function getEnvironmentConfig(env) {
  const configPath = 'cypress.env.json'
  const configJson = JSON.parse(fs.readFileSync(configPath))
  return configJson[env]
}

module.exports = defineConfig({
  video: false,
  chromeWebSecurity: false,
  pageLoadTimeout: 90000,
  viewportHeight: 1080,
  viewportWidth: 1920,
  e2e: {
    setupNodeEvents(on, config) {
      const envName = config.env.configFile || 'dev'
      const envConfig = getEnvironmentConfig(envName)

      return {
        ...config,
        env: {
          ...config.env,
          ...envConfig
        },
        baseUrl: envConfig.baseUrl
      }
    },
  },
});
