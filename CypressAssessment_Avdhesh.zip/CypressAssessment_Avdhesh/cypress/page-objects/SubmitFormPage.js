export class SubmitFormPage {

    fillName(name) {
        return cy.get('.aCsJod').click().type(name)
    }

    selectAgeUnder18() {
        return cy.contains('label', 'Under 18').click()
    }

    clickOnDropDown() {
        return cy.get('.ry3kXd').click()
    }

    selectExerciseEveryWeekToYes(Yes) {
        cy.contains('div[role="option"]', 'Yes').click();
    }

    submitForm() {
        return cy.contains('.NPEfkd', 'Submit')
            .click();
    }

    validateResponseText() {
        return cy.get('[class="vHW8K"]').should('have.text', 'Your response has been recorded.')
    }

    validateSubmitAnotherResponseLink() {
        return cy.get('.c2gzEf a')
            .should('have.attr', 'href')
            .and('include', 'https://docs.google.com/forms/')
    }

}