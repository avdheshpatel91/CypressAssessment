import { faker } from "@faker-js/faker"
import { SubmitFormPage } from "../../page-objects/SubmitFormPage"

const submitPage = new SubmitFormPage()

describe('Submit User form', () => {

    let name

    beforeEach(() => {

        name = faker.person.firstName()
        cy.visit(Cypress.env('baseUrl'))
    })

    it('should fill the form and submit', () => {

        submitPage.fillName(name)
        submitPage.selectAgeUnder18()
        submitPage.clickOnDropDown()
        submitPage.selectExerciseEveryWeekToYes()
        submitPage.submitForm()
        submitPage.validateResponseText()
        submitPage.validateSubmitAnotherResponseLink()
        cy.url().should('include', 'forms')
    })

})
